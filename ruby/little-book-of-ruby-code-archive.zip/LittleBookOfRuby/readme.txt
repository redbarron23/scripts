The Little Book Of Ruby (3rd edition)
written by
Huw Collingbourne
Copyright � 2011
SapphireSteel Software 
http://www.sapphiresteel.com
All rights reserved. 

This sample code is provided for use with The Little Book Of Ruby 
eBook available from: http://www.sapphiresteel.com

You may freely copy and distribute the Little Book Of Ruby eBook and the 
accompanying source code as long as you do not modify the text or remove 
the copyright notice from the eBook. You must not make any charge for the 
eBook or the accompanying source code. 

Users of Ruby In Steel (v 2.0) may load all sample programs as a single
Visual Studio Solution (LittleBookOfRuby.sln). With other editors and
IDEs, you will need to load each Ruby program file one at a time.

SapphireSteel Software are the developers of the Ruby In Steel IDE 
for Visual Studio

Huw Collingbourne is also author of an advanced book on Ruby programming, 
The Book Of Ruby, from No Starch Press: http://www.nostarch.com/boruby.htm
