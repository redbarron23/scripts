# Ruby Sample program from www.sapphiresteel.com 

class MyClass
	def saysomething
		puts( "Hello" )
	end
end

ob = MyClass.new
ob.saysomething
print( "Class of ob is: " )
puts( ob.class )

