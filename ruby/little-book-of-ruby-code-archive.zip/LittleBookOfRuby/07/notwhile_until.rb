# Ruby Sample program from www.sapphiresteel.com 

puts( "starting not while loop" )
i = 0
while i != 10
	print("#{i} ")
	i += 1
end
puts( "\nnot while loop ended" )

puts

puts( "starting until loop" )
i = 0
until i == 10
	print("#{i} ")
	i += 1
end
puts( "\nuntil loop ended" )