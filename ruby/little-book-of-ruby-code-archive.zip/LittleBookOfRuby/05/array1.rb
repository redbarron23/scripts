# Ruby Sample program from www.sapphiresteel.com

arr = ['a', 'b', 'c']

p(arr[0])  # shows �a�
p(arr[1])  # shows �b�
p(arr[2])  # shows �c�

p(arr[3]) # nil