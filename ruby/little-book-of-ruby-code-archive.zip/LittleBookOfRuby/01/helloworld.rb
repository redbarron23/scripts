# Ruby Sample program from www.sapphiresteel.com

puts 'Hello world'