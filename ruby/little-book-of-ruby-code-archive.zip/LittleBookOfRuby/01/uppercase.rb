# Ruby Sample program from www.sapphiresteel.com

puts( "hello world".upcase )